@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    py -3 start_server.py
    goto done
)
where python >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    python start_server.py
    goto done
)
echo Python 3 was not found. You can open index.html directly in Chrome or Edge.
echo For a microphone-friendly localhost version, install Python 3 from python.org.
pause
:done
