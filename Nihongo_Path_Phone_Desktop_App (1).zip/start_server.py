"""Local desktop launcher. No third-party dependencies. Python 3 required."""
from pathlib import Path
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
import threading
import webbrowser
import os

base = Path(__file__).resolve().parent
os.chdir(base)
port = 8765
for candidate in range(port, port + 20):
    try:
        server = ThreadingHTTPServer(("127.0.0.1", candidate), SimpleHTTPRequestHandler)
        port = candidate
        break
    except OSError:
        continue
else:
    raise SystemExit("No available local port found.")
url = f"http://localhost:{port}/index.html"
print("Nihongo Path is ready:", url)
print("Keep this window open while you study. Press Ctrl+C to stop.")
threading.Timer(1.0, lambda: webbrowser.open(url)).start()
try:
    server.serve_forever()
except KeyboardInterrupt:
    print("Stopping the study app...")
finally:
    server.server_close()
