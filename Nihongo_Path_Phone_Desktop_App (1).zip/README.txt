NIHONGO PATH — JAPANESE IMMERSION STUDIO
Version 1.0 · November 2026
======================================

WHAT IS INCLUDED
- 26 original, guided Japanese lessons (10 N5, 8 N4, 8 N3-oriented).
- Eight scripted real-life conversations: introductions, stores, cafes,
  planning, train directions, apartments, work, and clinic visits.
- Japanese text-to-speech and optional browser speech-to-text practice.
- Listening-first prompts, model answers, vocabulary and grammar.
- Spaced-repetition vocabulary cards from your completed lessons.
- Study recommendations: Genki, Bunpro, Renshuu and free resources.
- Local progress tracking, backup export and restore.
- A copyable prompt to continue open-ended practice in ChatGPT Voice.

EASIEST WAY TO USE IT ON A DESKTOP
1. Unzip the entire folder.
2. Double-click index.html and use Chrome or Edge.
3. For more dependable voice support, run Start-Nihongo-Path-Windows.bat
   (Windows and Python 3) or run "python start_server.py" in Terminal.
4. If using the server, it opens http://localhost:8765 automatically.

HOW TO PUT IT ON A PHONE
This is a Progressive Web App (PWA), NOT an App Store app.
You need an HTTPS website for installation and for microphone permissions.
One simple free path:
1. Unzip the folder.
2. Upload all app files to a static hosting service such as
   Netlify Drop (https://app.netlify.com/drop) or GitHub Pages.
   You must upload the FOLDER CONTENTS with index.html at the site root.
3. Open the resulting HTTPS URL on your phone.
4. Android / Chrome: menu > Install app or Add to Home screen.
   iPhone / Safari: Share > Add to Home Screen.
5. Allow microphone permission when asked.

IMPORTANT LIMITATIONS
- Voice recognition depends on your browser, permissions, device and
  often an internet connection. Chrome/Edge typically work best.
- The app does NOT provide live AI-generated conversations. Its role-plays
  are guided, scripted exercises. Use ChatGPT Voice separately for free-
  flowing dialogue and more flexible feedback.
- Speech recognition compares a transcript against a sample answer and
  cannot reliably grade accent, pronunciation, or all alternative replies.
- The N5/N4/N3 labels are approximate curriculum bands. They are not
  official JLPT certifications or guarantees of exam readiness.
- Progress is saved only in the browser on that device. Export your JSON
  from Settings if you want to back it up or transfer it to another device.
- The interface is designed to work offline after the PWA is installed,
  but voice recognition may require a connection.
- No paid services, user accounts, APIs or payment details are required.

SUGGESTED ROUTINE
- 30 min: conversation in ChatGPT Voice or the app's Voice Lab
- 15 min: Genki / later Quartet
- 10 min: Bunpro grammar review
- 10 min: Renshuu kanji + vocabulary review
- 10 min: Japanese listening or graded stories

This is an original learning companion, not affiliated with or using
licensed course contents from Pimsleur, Aimee, Bunpro, Genki or others.

ENJOY YOUR JAPANESE STUDIES! 頑張ってください。
